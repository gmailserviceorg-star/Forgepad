# Contributing

1. Fork the repository.
2. Create a branch for your change.
3. Keep the interface dependency-free unless a dependency has a strong reason to exist.
4. Test desktop and narrow mobile layouts.
5. Keep tools client-side when practical.
6. Open a pull request with a concise description and testing notes.
