# UtilityForge

A privacy-first, browser-based developer and writing workbench.

UtilityForge combines a clean text editor with practical tools for everyday work:

- Markdown editing with live preview
- JSON formatter/minifier
- Text diff
- Regex tester
- Base64 and URL encoding/decoding
- Case conversion and text statistics
- Reusable snippets
- Import/export text files
- Local autosave
- Keyboard shortcuts
- Responsive mobile + desktop layout
- Optional Python local server

Everything runs locally in your browser. No account and no external API are required.

## Run

### Browser-only
Open `frontend/index.html` directly in a modern browser.

### Python server
Recommended for a more app-like local experience:

```bash
python server.py
```

Then open:

`http://127.0.0.1:8000`

## Keyboard shortcuts

- `Ctrl/Cmd + S` — download the current editor text
- `Ctrl/Cmd + Enter` — run the active tool
- `Ctrl/Cmd + K` — focus the tool search
- `Ctrl/Cmd + Shift + S` — save the current text as a snippet

## Project structure

```text
UtilityForge/
├── frontend/
│   ├── index.html
│   ├── app.js
│   └── style.css
├── backend/
│   └── __init__.py
├── .github/
│   └── workflows/
│       └── static-check.yml
├── .gitignore
├── .gitattributes
├── LICENSE
├── CONTRIBUTING.md
├── SECURITY.md
├── server.py
└── README.md
```

## Privacy

UtilityForge does not send editor contents to a remote service. Data such as autosaves and snippets stays in the browser's local storage.

## License

MIT. See `LICENSE`.
