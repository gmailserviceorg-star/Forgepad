# Security

UtilityForge is designed to process user-provided text locally.

Please do not submit secrets, passwords, API keys, private documents, or other sensitive information in GitHub issues.

For a security vulnerability, contact the repository maintainer privately rather than publishing exploit details in an issue.
